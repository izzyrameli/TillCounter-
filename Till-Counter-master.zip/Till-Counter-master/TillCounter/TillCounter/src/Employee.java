
public class Employee {
	private int id;
	public Customer myCustomer; 
	
	public Employee(int id) {
		this.id = id;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
	public void addItem(int itemId)
	{
		
	}
	
	public void removeItem(int itemId)
	{
		
	}
	
	public void startDailyReport() {
		
	}
}
